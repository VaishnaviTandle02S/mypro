package org.example.appointmentbooking.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class DatabaseTestController {

    @Autowired
    private JdbcTemplate jdbcTemplate; // Inject JdbcTemplate for database operations

    @GetMapping("/test-database-connection")
    public String testDatabaseConnection() {
        try {
            // Execute a simple query to test the database connection
            int rowCount = jdbcTemplate.queryForObject("SELECT COUNT(*) FROM users", Integer.class);

            // Insert a test record into the database
           // jdbcTemplate.update("INSERT INTO users (id, username, email, contact_number, profession) VALUES (8, 'pinky', '[p@gmail.com', 9886843676, 'BA')");
            jdbcTemplate.update("INSERT INTO appointments (user_id, date, time, reason) VALUES (1, '2024-04-02', '10:00', 'Regular checkup')");
            return "Database connection test successful. Rows in table: " + rowCount;
        } catch (Exception e) {
            e.printStackTrace();
            return "Database connection test failed. Error: " + e.getMessage();
        }
    }
}

/*
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class DatabaseTestController {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @GetMapping("/test-database-connection")
    public String testDatabaseConnection() {
        try {
            jdbcTemplate.execute("SELECT 1");
            return "Database connection test successful.";
        } catch (Exception e) {
            return "Database connection test failed. Error: " + e.getMessage();
        }
    }

    @PostMapping("/insertAppointment")
    public String insertAppointment() {
        try {
            String sql = "INSERT INTO appointments (user_id, date, time, reason) VALUES (1, '2024-04-02', '10:00 AM', 'Regular checkup')";
            jdbcTemplate.update(sql);
            return "Appointment inserted successfully.";
        } catch (Exception e) {
            return "Failed to insert appointments. Error: " + e.getMessage();
        }
    }
}*/