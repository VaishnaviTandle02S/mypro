package org.example.appointmentbooking.service;

import org.example.appointmentbooking.exception.RegistrationException;
import org.example.appointmentbooking.exception.UserNotFoundException;
import org.example.appointmentbooking.model.User;

public interface UserService {
    User registerUser(User user) throws RegistrationException;
    User getUserById(Long id) throws UserNotFoundException;
    User updateUser(Long id, User user) throws UserNotFoundException;
    void deleteUser(Long id) throws UserNotFoundException;
}

