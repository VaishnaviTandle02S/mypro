package org.example.appointmentbooking.exception;

public class UserNotFoundException extends Throwable {
    public UserNotFoundException(String s) {
    }
}
