package org.example.appointmentbooking.controller;

import org.example.appointmentbooking.exception.RegistrationException;
import org.example.appointmentbooking.exception.UserNotFoundException;
import org.example.appointmentbooking.model.User;
import org.example.appointmentbooking.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;


@RestController
@RequestMapping("/api/users")
public class UserController {

    @GetMapping("/index")
    public String showIndex() {
        return "index"; // Assuming you have a form.html file in your resources/templates directory
    }

    @PostMapping("/Register")
    public String Register(@RequestParam String username,
                             @RequestParam String email,
                             @RequestParam String contactNumber,
                             @RequestParam String profession,
                             Model model) {
        // Process form data here
        model.addAttribute("username", username);
        model.addAttribute("email", email);
        model.addAttribute("contactNumber", contactNumber);
        model.addAttribute("profession", profession);

        return "confirmation"; // Assuming you have a confirmation.html file in your resources/templates directory
    }

    @Autowired
    private UserService userService;

    @PostMapping("/register")
    public ResponseEntity<String> registerUser(@RequestBody User user) throws RegistrationException {
        userService.registerUser(user); // Assuming UserService is properly implemented
        return ResponseEntity.ok("User registered successfully!");
    }

    @GetMapping("/{id}")
    public ResponseEntity<User> getUserById(@PathVariable Long id) throws UserNotFoundException {
        User user = userService.getUserById(id);
        return ResponseEntity.ok(user);
    }

    @PutMapping("/{id}")
    public ResponseEntity<User> updateUser(@PathVariable Long id, @RequestBody User user) throws UserNotFoundException {
        User updatedUser = userService.updateUser(id, user);
        //return new ResponseEntity<>("User updated successfully", HttpStatus.OK);
        return ResponseEntity.ok(updatedUser);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteUser(@PathVariable Long id) throws UserNotFoundException {
        userService.deleteUser(id);
        return ResponseEntity.ok().build();
        /*@Bean
    public PasswordEncoder passwordEncoder () {
        return new BCryptPasswordEncoder();
    }*/

        // Implement methods for update and delete operations
    }
}