package org.example.appointmentbooking.exception;

public class RegistrationException extends Exception {
    public RegistrationException(String username_is_already_taken)  {
        super(username_is_already_taken);

    }
}
