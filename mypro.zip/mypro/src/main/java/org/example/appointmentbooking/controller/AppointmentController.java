package org.example.appointmentbooking.controller;

import org.example.appointmentbooking.exception.AppointmentException;
import org.example.appointmentbooking.exception.AppointmentNotFoundException;
import org.example.appointmentbooking.service.AppointmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/appointments")
public class AppointmentController<Appointment> {

    @GetMapping("/home")
    public String showHome() {
        return "home"; // Assuming you have a form.html file in your resources/templates directory
    }

    @PostMapping("/bookAppointment")
    public String bookAppointment(@RequestParam String date,
                                  @RequestParam String time,
                                  @RequestParam String reason,
                                  Model model) {
        // Process form data here

        model.addAttribute("date", date);
        model.addAttribute("time", time);
        model.addAttribute("reason", reason);


        return "home"; // Assuming you have a confirmation.html file in your resources/templates directory
    }

    @Autowired
    private AppointmentService appointmentService;

    @PostMapping("/api/book")
    public ResponseEntity<String> bookAppointment(@RequestBody Appointment appointment) throws AppointmentException {
        appointmentService.bookAppointment((org.example.appointmentbooking.model.Appointment) appointment); // Assuming AppointmentService is properly implemented
        return ResponseEntity.ok("Appointment booked successfully!");
    }

    @GetMapping("/{id}")
    public ResponseEntity<Appointment> getAppointmentById(@PathVariable Long id) throws AppointmentNotFoundException {
        Appointment appointment = (Appointment) appointmentService.getAppointmentById(id);
        return ResponseEntity.ok(appointment);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Appointment> updateAppointment(@PathVariable Long id, @RequestBody Appointment appointment) throws AppointmentNotFoundException {
        Appointment updatedAppointment = (Appointment) appointmentService.updateAppointment(id, (org.example.appointmentbooking.model.Appointment) appointment);
        return ResponseEntity.ok(updatedAppointment);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> cancelAppointment(@PathVariable Long id) throws AppointmentNotFoundException {
        appointmentService.cancelAppointment(id);
        return ResponseEntity.ok().build();
    }
}

