package org.example.appointmentbooking.controller;

import org.example.appointmentbooking.exception.AppointmentException;
import org.example.appointmentbooking.exception.AppointmentNotFoundException;
import org.example.appointmentbooking.service.AppointmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/appointments")
public class AppointmentController<Appointment> {

    /*@GetMapping("/index")
    public String showIndex() {
        return "index"; // Assuming you have a form.html file in your resources/templates directory
    }

    @PostMapping("/submitForm")
    public String submitForm(@RequestParam String username,
                             @RequestParam String email,
                             @RequestParam String contactNumber,
                             @RequestParam String profession,
                             Model model) {
        // Process form data here
        model.addAttribute("username", username);
        model.addAttribute("email", email);
        model.addAttribute("contactNumber", contactNumber);
        model.addAttribute("profession", profession);

        return "confirmation"; // Assuming you have a confirmation.html file in your resources/templates directory
    } */

    @Autowired
    private AppointmentService appointmentService;

    @PostMapping("/api/book")
    public ResponseEntity<String> bookAppointment(@RequestBody Appointment appointment) throws AppointmentException {
        appointmentService.bookAppointment((org.example.appointmentbooking.model.Appointment) appointment); // Assuming AppointmentService is properly implemented
        return ResponseEntity.ok("Appointment booked successfully!");
    }

    @GetMapping("/{id}")
    public ResponseEntity<Appointment> getAppointmentById(@PathVariable Long id) throws AppointmentNotFoundException {
        Appointment appointment = (Appointment) appointmentService.getAppointmentById(id);
        return ResponseEntity.ok(appointment);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Appointment> updateAppointment(@PathVariable Long id, @RequestBody Appointment appointment) throws AppointmentNotFoundException {
        Appointment updatedAppointment = (Appointment) appointmentService.updateAppointment(id, (org.example.appointmentbooking.model.Appointment) appointment);
        return ResponseEntity.ok(updatedAppointment);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> cancelAppointment(@PathVariable Long id) throws AppointmentNotFoundException {
        appointmentService.cancelAppointment(id);
        return ResponseEntity.ok().build();
    }
}

