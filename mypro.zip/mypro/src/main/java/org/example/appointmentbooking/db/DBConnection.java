package org.example.appointmentbooking.db;
import java.sql.PreparedStatement;


        import java.sql.Connection;
        import java.sql.DriverManager;
        import java.sql.SQLException;

public class DBConnection {

    private static final String URL = "jdbc:mysql://localhost:3306/myfirst";
    private static final String USERNAME = "root";
    private static final String PASSWORD = "V@1sh#676";

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USERNAME, PASSWORD);
    }

    public static void insertUser(String username, String email, String contact_number, String profession) {
        String sql = "INSERT INTO users (username, email, contact_number, profession) VALUES ('vaish','V@gmail.com','9686843676','BE')";

        try (Connection connection = getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(sql)) {

            preparedStatement.setString(1, username);
            preparedStatement.setString(2, email);
            preparedStatement.setString(2, contact_number);
            preparedStatement.setString(2, profession);

            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("User inserted successfully.");
            } else {
                System.out.println("Failed to insert user.");
            }

            // preparedStatement.executeUpdate();
            //System.out.println("User inserted successfully.");

        } catch (SQLException e) {
            System.err.println("Error inserting user: " + e.getMessage());
        }
    }
}
