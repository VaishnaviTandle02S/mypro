package org.example.appointmentbooking.service;

import org.example.appointmentbooking.exception.AppointmentNotFoundException;
import org.example.appointmentbooking.model.Appointment;
import org.example.appointmentbooking.repository.AppointmentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class AppointmentServiceImpl implements AppointmentService {

    @Autowired
    private AppointmentRepository appointmentRepository;

    @Override
    public Appointment bookAppointment(Appointment appointment)  {
        return appointmentRepository.save(appointment);
    }

    @Override
    public List<Appointment> getAllAppointments() {
        return appointmentRepository.findAll();
    }

    @Override
    public Appointment getAppointmentById(Long id) throws AppointmentNotFoundException {
        Optional<Appointment> appointmentOptional = appointmentRepository.findById(id);
        Optional<Object> AppointmentOptional = null;
        if (AppointmentOptional.isPresent()) {
            return (Appointment) AppointmentOptional.get();
        } else {
            throw new AppointmentNotFoundException("Appointment not found with ID: " + id);
        }
        //return appointmentOptional.orElseThrow(() -> new AppointmentNotFoundException("Appointment not found with ID: " + id));
    }

    @Override
    public Appointment updateAppointment(Long id, Appointment appointment) throws AppointmentNotFoundException {
        if (!appointmentRepository.existsById(id)) {
            throw new AppointmentNotFoundException("Appointment not found with ID: " + id);
        }
        Appointment updatedAppointment = null;
        updatedAppointment.setId(id); // Ensure the ID is set
        appointmentRepository.save(updatedAppointment);


        return updatedAppointment;
    }

    @Override
    public void cancelAppointment(Long id) throws AppointmentNotFoundException {
        if (!appointmentRepository.existsById(id)) {
            throw new AppointmentNotFoundException("Appointment not found with ID: " + id);
        }
        appointmentRepository.deleteById(id);
    }
}
