package org.example.appointmentbooking.service;

import org.example.appointmentbooking.exception.AppointmentException;
import org.example.appointmentbooking.exception.AppointmentNotFoundException;
import org.example.appointmentbooking.model.Appointment;

import java.util.List;

public interface AppointmentService {
    Appointment bookAppointment(Appointment appointment) throws AppointmentException;

    List<Appointment> getAllAppointments();

    Appointment  getAppointmentById(Long id) throws AppointmentNotFoundException;

    Appointment  updateAppointment(Long id, Appointment appointment) throws AppointmentNotFoundException;

    void cancelAppointment(Long id)throws AppointmentNotFoundException;
}
