package org.example.appointmentbooking.exception;

public class AppointmentNotFoundException extends Throwable {
    public AppointmentNotFoundException(String s) {
    }
}
