package org.example.appointmentbooking.service;

import org.example.appointmentbooking.exception.RegistrationException;
import org.example.appointmentbooking.exception.UserNotFoundException;
import org.example.appointmentbooking.model.User;
import org.example.appointmentbooking.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private  PasswordEncoder passwordEncoder;

    public void  UserServiceImpl(PasswordEncoder passwordEncoder) {
        this.passwordEncoder = passwordEncoder;
    }


    @Override
    public User registerUser(User user) throws RegistrationException {
        // Check if username is already taken
        if (userRepository.existsByUsername(user.getUsername())) {
            throw new RegistrationException("Username is already taken");
        }

        // Encode the password before saving to the database
        String encodedPassword = passwordEncoder.encode(user.getPassword());

        // Set the encoded password to the user object
        user.setPassword(encodedPassword);

        // Save the user to the database
        userRepository.save(user);

        return user;
    }
    @Override
    public User getUserById(Long id) throws UserNotFoundException {
        Optional<User> userOptional = userRepository.findById(id);
        if (userOptional.isPresent()) {
            return userOptional.get();
        } else {
            throw new UserNotFoundException("User not found with ID: " + id);
        }
    }

    @Override
    public User updateUser(Long id, User user) throws UserNotFoundException {
        // Retrieve the user from the database
        User existingUser = userRepository.findById(id)
                .orElseThrow(() -> new UserNotFoundException("User not found with ID: " + id));

        // Update user details with the provided data
        existingUser.setUsername(user.getUsername());
        existingUser.setEmail(user.getEmail());
        // Update other user details as needed

        // Save the updated user to the database
        User updatedUser = userRepository.save(existingUser);

        return updatedUser;
    }

    @Override
    public void deleteUser(Long id) throws UserNotFoundException {
        // Retrieve the user from the database
        User user = userRepository.findById(id)
                .orElseThrow(() -> new UserNotFoundException("User not found with ID: " + id));

        // Delete the user from the database
        userRepository.delete(user);
    }

}
