package org.example.appointmentbooking.config;

import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;

public class WebSecurityConfigurerAdapter {
    protected void configure(HttpSecurity http) throws Exception {

    }

    protected void configure(AuthenticationManagerBuilder auth) throws Exception {

    }
}
