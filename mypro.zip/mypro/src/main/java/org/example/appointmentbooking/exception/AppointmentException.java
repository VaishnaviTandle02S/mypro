package org.example.appointmentbooking.exception;

public class AppointmentException extends Throwable {
}
