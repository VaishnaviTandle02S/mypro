function registerUser() {
    // Fetch input values
    var name = document.getElementById('name').value;
    var email = document.getElementById('email').value;
    var contact = document.getElementById('contact').value;
    var profession = document.getElementById('profession').value;

     // Create a User object
     var user = {
            name: name,
            email: email,
            contact: contact,
            profession: profession
        };
    // Perform validation if required

    // Send data to backend for registration
    // Example:
    fetch('/api/register', {
        method: 'POST',
        body: JSON.stringify(user),
        headers: {
          'Content-Type': 'application/json'
        }
     }).then(response => {
     // Handle response
    }).catch(error => {
        console.error('Error:', error);
    });
    window.location.href = "confirmation.html";

}

function bookAppointment() {
    // Fetch input values
    var date = document.getElementById('date').value;
    var time = document.getElementById('time').value;
    var reason = document.getElementById('reason').value;

    // Perform validation if required

    // Send data to backend for booking appointment
    // Example:
    fetch('/api/book-appointment', {
        method: 'POST',
         body: JSON.stringify({ date, time, reason }),
         headers: {
            'Content-Type': 'application/json'
         }
     }).then(response => {
        // Handle response
    }).catch(error => {
        console.error('Error:', error);
    });
}

// Function to load calendar view - implement as per requirement
function loadCalendar() {
    // This function can load a calendar view using JavaScript
    // You can use libraries like FullCalendar.js or implement custom logic
}

// Call loadCalendar function when page loads
window.onload = function() {
    loadCalendar();
};